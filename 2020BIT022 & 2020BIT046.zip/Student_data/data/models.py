from django.db import models

# Create your models here.
class Student(models.Model):
         Student_name = models.CharField(max_length=122)
         Reg_no = models.CharField(max_length=122)
         Address= models.CharField(max_length=122)
         Taluka = models.CharField(max_length=122)
         District = models.CharField(max_length=122)
         State = models.CharField(max_length=122)
         Photo = models.ImageField()
         Pincode = models.IntegerField(max_length=6)
         def __str__(self):
             return self.Reg_no

class Admission(models.Model):
    Reg_no = models.ForeignKey(Student, blank=True,null=True, on_delete=models.CASCADE)
    Student_name = models.CharField( max_length=120)
    Branch = models.CharField( max_length=50)
    Class = models.CharField( max_length= 50)
    Date_of_admission = models.IntegerField (max_length= 20)
    Semester = models.CharField (max_length= 20)
    def __str__(self):
	    return self.Student_name
  

class marks(models.Model):
    Reg_no = models.ForeignKey(Student, blank=True,null=True, on_delete=models.CASCADE)
    Student_name = models.CharField( max_length=120)
    Subject = models.CharField(max_length=122) 
    marks = models.IntegerField(max_length=122)
    Semester = models.CharField(max_length=122)
    Year = models.IntegerField(max_length=122)
    def __str__(self):
             return self.Student_name + ' ' + self.marks

class Feedback(models.Model):
    Reg_no = models.ForeignKey(Student, blank=True,null=True, on_delete=models.CASCADE)
    Student_name = models.CharField( max_length=120)
    Date=models.DateField()
    marks = models.ForeignKey(marks, blank=True,null=True, on_delete=models.CASCADE)
    Subject=models.CharField(max_length=122)
    Feedback=models.TextField()
    def __str__(self):
             return self.Student_name
         