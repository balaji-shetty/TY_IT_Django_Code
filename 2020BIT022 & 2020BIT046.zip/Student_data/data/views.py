from django.shortcuts import render, HttpResponse
from datetime import datetime
from django.contrib import messages
from data.models import Admission
from data.models import Student
from data.models import marks
from data.models import Feedback
from django.shortcuts import render

def all_events(request):
    Admission_list= Admission.objects.all()
    return render(request,'event.html', 
    {'Admission_list': Admission_list})

def all_events2(request):
    Context = {}
    name = request.POST.get('name')
    Context['name'] = name
    Admission_list= Admission.objects.all()
    for x in Admission_list:
        if x.Student_name == name:
            Context['Reg_no']=x.Reg_no
            Context['Branch']=x.Branch
            Context['Class']=x.Class
            Context['Semester']=x.Semester
    Student_list= Student.objects.all()
    for x in Student_list:
        if x.Student_name == name:
            Context['Address']=x.Address
            Context['District']=x.District
            Context['State']=x.State
            Context['Photo']=x.Photo
            Context['Pincode']=x.Pincode
    Marks_list = marks.objects.all()
    # for x in Marks_list:
    #     if x.Student_name == name:
    #         Context['Subject']=x.Subject
    #         Context['marks']=x.marks
    #         Context['Semester']=x.Semester
    #         Context['Year']=x.Year
            
    return render(request,'event2.html', Context)

def index(request):
    return render(request, 'index.html')